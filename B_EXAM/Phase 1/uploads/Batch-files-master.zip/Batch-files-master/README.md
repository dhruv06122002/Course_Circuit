Batch-files
===========

|Batch files and fun with them
----
| some fun creating small games type of .bat files 
